# cali_fires

Very rough starter code to process live data for maps for socal fires